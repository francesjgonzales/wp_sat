<?php
get_header();
?>

<div class="container mt-5">
    <h3> <?php the_title() ?></h3>
    <?php the_content() ?>


</div>


<?php
get_footer();
?>