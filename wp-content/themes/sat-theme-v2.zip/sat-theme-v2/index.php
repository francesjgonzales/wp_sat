<?php
/* Template Name: / */
wp_head()
?>

<div class="container-fluid p-5 mt-5">
    <div class="row align-items-start">
        <h1> Welcome to Student Attendance Tracker </h1>

    </div>
</div>

<?php
get_footer();
?>