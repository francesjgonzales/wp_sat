<?php
/* Template Name: / */
wp_head()
?>

<div class="container-fluid p-5 mt-5">
    <div class="row align-items-start">
        <?php the_content() ?>
    </div>
</div>

<?php
get_footer();
?>