<?php
get_header();
?>

<?php
the_title();
the_content();
?>