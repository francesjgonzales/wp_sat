<?php
/* Template Name: Register */
wp_head()
?>
<h1>Register</h1>


<article class="mt-5 pt-5">

    <?php the_content() ?>


</article>

<?php
get_footer();
?>