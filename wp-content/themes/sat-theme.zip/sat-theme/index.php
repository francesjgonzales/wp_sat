<?php
wp_head()
?>

    <?php
    get_footer();
    ?>