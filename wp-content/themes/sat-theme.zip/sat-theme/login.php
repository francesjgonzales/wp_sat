<?php
/* Template Name: Login */
wp_head()
?>
<h1>Login</h1>


<article class="mt-5 pt-5">

    <?php the_content() ?>

    <!--     <form>
        <div class="mb-3">
            <label for="studentNameInput" class="form-label">Student Name</label>
            <input type="student" class="form-control" id="studentInput" aria-describedby="student">
        </div>
        <div class="mb-3">
            <label for="parentInput" class="form-label">Parent</label>
            <input type="parent" class="form-control" id="parentInput">
        </div>
        <div class="mb-3">
            <label for="emergencyContactInput" class="form-label">Emergency Contact</label>
            <input type="emergencyContact" class="form-control" id="emergencyContactInput">
        </div>
        <div class="mb-3">
            <label for="classInput" class="form-label">Class</label>
            <input type="class" class="form-control" id="classInput">
        </div>
        <div class="mb-3">
            <label for="teacherInput" class="form-label">Teacher</label>
            <input type="teacher" class="form-control" id="teacherInput">
        </div>

        <div class="mb-3 form-check">
            <input type="checkbox" class="form-check-input" id="exampleCheck1">
            <label class="form-check-label" for="exampleCheck1">Check me out</label>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form> -->


</article>

<?php
get_footer();
?>